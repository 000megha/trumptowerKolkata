<?php include 'include/header.php'; ?>

<!-- THANK part  -->
<div class="thank container-fluid py-5 bg-dark" id="process">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-md-9 text-center thnx-mid">

        <h1 class="text-primary" style="margin-bottom: 20px;">THANK YOU</h1>
        <h4 class="text-light" style="margin-bottom: 25px;">Our advisor will get in touch with you shortly.</h4>
        <!-- <a href="index.php" target="_blank[]" class="btn">Back To Home</a> -->
        <div class="btn-grup">
          <a href="index.php" class="btn golden me-md-4">go Back to home page</a>
          <a href="pdf/3-BED-WITH-STUDY.pdf" download="pdf/3-BED-WITH-STUDY.pdf" class="btn golden">Download
            brochure</a>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- THANK part  -->
<?php include 'include/footer.php'; ?>