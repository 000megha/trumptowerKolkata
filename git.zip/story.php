<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="banner  " id="section1">
  <div class="banner-img">
    <img src="img/story/story1.webp" />
  </div>
  <div class="banner-heading">
    <h5 class="bannn-small" data-aos="fade-up">Your first taste of the Trump experience comes after your last stop in the fast-growing
      metropolis of Kolkata. ​Your personal chauffeur ​carries you away to an address of global prestige ​ that can be
      seen from everywhere.​</h5>
    <h5 class="bannn-small" data-aos="fade-down">As much as you enjoy living minutes from Science City, inspired cuisine, and cultural
      pleasures, home is a necessary private refuge.</h5>
  </div>

  <div class="page__scroll">
    <div class="squares">
      <div class="square"></div>
      <div class="squaretwo"></div>
    </div>
    <p> SCROLL</p>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner one End -->
<?php include 'include/secondrynav.php'; ?>

<!-- banner two Start -->
<div class="story1 py-5" id="section1">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-9 ">
        <div class="story-outer" data-aos="fade-down">
          <div class="story-img">
            <img src="img/story/story-new1.webp" class="img-fluid" data-aos="fade-up"/>
            <h2 class="img-title" >Entrance Gateway</h2>
          </div>
          <div class="story-text" data-aos="fade-down">
            <p class="text-light">You drive through the grand entrance gateway, onto the <strong>generous 200-meter
                driveway</strong> to the entrance of the lobby.</p>
            <p class="text-light">Like a fortress, the entire podium is sheltered by lush evergreen hedges and a
              water-filled moat.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner two End -->


<!-- banner three Start -->
<div class="story2 py-5" id="section1">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-9 ">
        <div class="story-outer">
          <div class="story-img">
            <img src="img/story/story-new2.webp" class="img-fluid" data-aos="fade-down"/>
          </div>
          <div class="story-text">
            <p class="text-light" data-aos="fade-up">The lobby’s glass-enclosed entryway and open, double height ceiling make a welcome
              transition into a more quieted community. <strong>The valet attendants and doormen greet</strong> you
              graciously as you approach.</p>

          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner three End -->

<!-- banner four Start -->
<div class="story3 py-5" id="section1">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-9 ">
        <div class="story-outer">
          <div class="story-img">
            <img src="img/story/story-new-6.webp" class="img-fluid" data-aos="fade-down" />
            <h2 class="img-title">Living Room</h2>
          </div>
          <div class="story-text" data-aos="fade-up">
            <p>Your living room is an expression of how you prefer to luxuriate in your free time – of your ideal space
              for social gatherings and relaxing pastimes.</p>
            <p>As the evening light crowns the outline of the city and warms the room through the
              <strong>floor-to-ceiling windows</strong>, you usually like to prepare for a few hours of uninterrupted
              game time.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner four End -->

<!-- banner five Start -->
<div class="story4 py-5" id="section1">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-9 ">
        <div class="story-outer" data-aos="fade-down">
          <div class="story-img">
            <img src="img/story/story-new5.webp" class="img-fluid" data-aos="fade-up"/>
            <h2 class="img-title">Master Bathroom</h2>
          </div>
          <div class="story-text" >
            <p class="text-light" data-aos="fade-down">Your most refreshing moments are when you leave the company of others and rinse away
              the day in a <strong>spacious shower</strong>.</p>
            <p class="text-light" data-aos="fade-down">Though above the sightline of neighboring buildings, you know they and every other
              part of the world have their eyes on your home.</p>

          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner five End -->


<!-- banner six Start -->
<div class="story5 py-5" id="section1">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-9 ">
        <div class="story-outer" data-aos="fade-up">
          <div class="story-img">
            <img src="img/story/story-new4.webp" class="img-fluid" data-aos="fade-down" />
            <h2 class="img-title">Master Bedroom</h2>
          </div>
          <div class="story-text" data-aos="fade-up">
            <p>This is where time comes to a complete halt. The seamless relationship between the sky and the space is
              all that occupies you. Everything else – the roar of the city, the family chatter – is put to rest.</p>
            <p>At night, you get into a fresh bed and your mind drifts into your favorite novel, calmed by the sweet
              tranquility of miles of unobstructed star light.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner six End -->

<!-- banner seven Start -->
<div class="story3 py-5" id="section1">
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-md-9 ">
        <div class="story-outer">
          <div class="story-img">
            <img src="img/story/story-new3.webp" class="img-fluid" data-aos="fade-up"/>
            <h2 class="img-title">Skye Club</h2>
          </div>
          <div class="story-text" data-aos="fade-down">
            <p>You get to take an elevator straight up to the <strong>rooftop Skye Club</strong>. As a valued member of
              the Trump family, you are one of the select few to experience the <strong>height of luxury</strong>.</p>
            <p>It’s a refreshing escape. Where you can wade into a <strong>sun-facing pool</strong> and bask in
              <strong>360 degree views</strong>. Everything lies before and below you – the full cityscape with the lake
              and luscious gardens.</p>
            <p>Post-swim, there are <strong>chaise lounges</strong> for relaxing on the surrounding terrace. And
              <strong>fire pits</strong>, around which you spend many blissful evenings with family and guests.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- banner seven End -->
<div class="footer-top py-5">
  <a href="residence.php">EXPLORE THE RESIDENCES</a>
</div>
<?php include 'include/footer.php'; ?>