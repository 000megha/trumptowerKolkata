<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="banner  pb-md-4  bg-dark" id="section1">
  <div class="banner-img">
    <img src="img/building/buildingv5-1900x894.webp" />
  </div>
  <div class="banner-heading">
    <h5 class="bannn-small" data-aos="fade-down">With only the finest quality materials and finishes, Trump Tower Kolkata was crafted for the connoisseurs of refined urban living. Impeccably designed residences, complemented by a steep glass facade and refined architecture, are inspired by the spirit of Manhattan extravagance.</h5>
  </div>

  <div class="page__scroll">
    <div class="squares">
      <div class="square"></div>
      <div class="squaretwo"></div>
    </div>

    <p> SCROLL</p>
  </div>

</div>
<div class="spacer">  
</div>
<!-- banner one End -->
<?php include 'include/secondrynav.php'; ?>
<!-- banner four Start -->
<div class="banner" id="section4">
  <div class="banner-img" data-aos="fade-down">
    <img src="img/building/building_2.webp"  />
  </div> 
</div>
<div class="spacer">  
</div>
<!-- banner four End -->

<!-- banner five Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
     <div class="col-md-3">
      <p class="para" data-aos="fade-left">
      Take a private luxury car to the entrance of a glass-enclosed lobby and join our gracious community.
      </p>
      <p class="para" data-aos="fade-right">
      The Trump family welcomes you to a life of perfection, exclusivity and refinement.
      </p>
		 <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
     </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/building/building_2.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">  
</div>
<!-- banner five End -->

<!-- banner three Start -->

<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row g-md-5">
      <div class="col-md-7">
        <div class="right-part">
          <div class="row">
            <div class="col-md-12">
              <div class="main-heading">
                <h5 data-aos="fade-down">THE CHOICE OF THE MOST SPECTACULAR VIEWS AND INTERIORS BELONGS TO YOU</h5>
              </div>
            </div>
            <div class="col-md-9">
            <img src="img/building/building4-1024x708.webp" class="img-fluid" data-aos="fade-right"/>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5">
        <div class="left-part">
          <img src="img/building/building_2-571x1024.webp" class="img-fluid" data-aos="fade-left"/>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- banner three End -->
<div class="footer-top py-5">
  <a href="story.php" data-aos="fade-down">EXPLORE THE STORY</a>
</div>


<?php include 'include/footer.php'; ?>