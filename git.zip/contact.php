<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="banner  d-none d-lg-block" id="section1">
    <div class="banner-img">
        <img src="img/contact/building_3-1900x894.webp" />
    </div>
    <div class="banner-heading">
        <h3 class="bannn-middle" data-aos="fade-down">ABOUT TRUMP TOWER KOLKATA</h3>
        <h5 class="bannn-small" data-aos="fade-down">Trump is introducing an address of global prestige to Kolkata’s
            rich cityscape. Trump Tower Kolkata was crafted with only the finest quality materials for the connoisseurs
            of refined urban living. It is unique in its cultivated blend of classic and contemporary residences –
            celebrating an individualized sense of ultimate luxury. Yet like all Trump properties, every room offers
            stunning, panoramic views, complemented and enhanced by an unparalleled host of private services and
            amenities.</h5>
    </div>
</div>
<div class="spacer">
</div>
<!-- banner one End -->

<div class="contact py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="gmap" data-aos="fade-up">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29477.56590372622!2d88.36388977561252!3d22.553067688331755!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0276a253455555%3A0x51e10dcdb4464447!2z4Kaf4KeN4Kaw4Ka-4Kau4KeN4KaqIOCmn-CmvuCmk-Cmr-CmvOCmvuCmsCBUcnVtcCBUb3dlcg!5e0!3m2!1sen!2sin!4v1698926784279!5m2!1sen!2sin"
                        width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            <div class="col-md-5">
                <div class="form-outer">
                    <div class="form-container" data-aos="fade-down">
                        <h4 class="text-dark mb-4">
                            CONTACT FORM
                        </h4>
                        <form action="mail.php" method="post" autocomplete="off">
                            <div class="form-group">
                                <label for="name">* Name:</label>
                                <input type="text" id="name" name="name" placeholder="Name" required>
								<div id="nameError" class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="email">* Email:</label>
                                <input type="text" id="email" name="email" placeholder="Email" required>
								<div id="emailError" class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="mobile">* Phone Number:</label>
                                <input type="text" id="mobile" name="mobile" placeholder="Phone Number" required>
								<div id="mobileError" class="error-message"></div>
                            </div>
								 <div class="form-group">
                                <label for="mobile">* Choose Your Preferred Flat Type:</label>
                                    <select class=" form-control form-select" tabindex="5"
                                            aria-label="Default select example" id="flattype" name="flattype" required>
                                            <option value="" disabled="disabled" selected>Select Flat type*</option>
                                            <option value="4BHK">4BHK 5.5CR</option>
                                            <option value="5BHK">5BHK 7CR</option>
                                        </select>
									 <div id="flattypeError" class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="message"> Message:</label>
                                <textarea id="message" name="message" class="form-control"
                                    placeholder="Enter Your Message" rows="2" cols="50"></textarea>
                            </div>
                            <input type="hidden" id="srd" name="srd">
                            <input type="submit" name="button" onclick="return validateForm()" value="Submit"
                                class="btn custombtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- banner one Start -->
<div class="banner  d-lg-none" id="section1">
    <div class="banner-img">
        <img src="img/contact/building_3-1900x894.webp" />
    </div>
    <div class="banner-heading">
        <h3 class="bannn-middle" data-aos="fade-down">ABOUT TRUMP TOWER KOLKATA</h3>
        <h5 class="bannn-small" data-aos="fade-down">Trump is introducing an address of global prestige to Kolkata’s
            rich cityscape. Trump Tower Kolkata was crafted with only the finest quality materials for the connoisseurs
            of refined urban living. It is unique in its cultivated blend of classic and contemporary residences –
            celebrating an individualized sense of ultimate luxury. Yet like all Trump properties, every room offers
            stunning, panoramic views, complemented and enhanced by an unparalleled host of private services and
            amenities.</h5>
    </div>
</div>
<div class="spacer">
</div>
<!-- banner one End -->

<?php include 'include/footer.php'; ?>