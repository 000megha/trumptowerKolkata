<?php include 'include/header.php'; ?>
<?php include 'include/modalform.php'; ?>
<?php include 'include/broshure.php'; ?>

<!-- banner one Start -->
<div class="banner bg-light  " id="section1">
  <div class="banner-img">
    <img src="img/index/home-page-1900x894.webp" />
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">TRUMP IS REDEFINING <br>THE KOLKATA SKYLINE 4 & 5 BHK STARTING AT 5.5CR.</h3>
    <div class="btn-grup">
    <a href="" class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</a>
    <a href="" class="btn " data-bs-toggle="modal" data-bs-target="#exampleModal2">Download brochure</a>
    </div>
  </div>

  <div class="page__scroll">
    <div class="squares">
      <div class="square"></div>
      <div class="squaretwo"></div>
    </div>

    <p> SCROLL</p>
  </div>

</div>
<!-- <div class="spacer pt-md-5 pt-4 bg-dark"> 
</div> -->
<!-- banner one End -->
<?php include 'include/secondrynav.php'; ?>
<!-- banner two Start -->
<div class="banner  parallax-img" id="section2" data-aos="fade-down" style=" background-image: url('img/index/sky-1900x1900.webp');background-attachment: fixed;">
  <div class="banner-img " style=" 
  z-index:9;" >
    <img src="img/index/trump-towers-1900x1900.webp"  />
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" >A LANDMARK FOR THE CITY OF KOLKATA, LOCATED BEHIND THE SCIENCE CITY</h3>
  </div>
  <!-- <img src="img/index/trump-towers-1900x1900.webp" class="animation-img" /> -->
</div>
<!-- <div class="spacer pt-md-5 pt-4 bg-dark">  
</div> -->
<!-- banner two End -->

<!-- banner three Start -->

<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row g-md-5">
      <div class="col-md-7">
        <div class="right-part">
          <div class="row">
            <div class="col-md-12">
              <div class="main-heading" data-aos="fade-right">
                <h5>THE CHOICE OF THE MOST SPECTACULAR VIEWS AND INTERIORS BELONGS TO YOU</h5>
				   <div class="btn golden me-md-4 mt-3" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
              </div>
            </div>
            <div class="col-md-6">
            <img src="img/index/living-1.webp" class="img-fluid" data-aos="fade-up"/>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5">
        <div class="left-part">
          <img src="img/index/homepage-1-768x1006.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- <div class="spacer pt-md-5 pt-4 bg-dark">  
</div> -->
<!-- banner three End -->

<!-- banner four Start -->
<div class="banner d-none d-lg-block" id="section4">
  <div class="banner-img" data-aos="fade-down">
    <img src="img/index/TTK-Lobby-1900x1343.webp"  />
  </div> 
</div>
<!-- <div class="spacer pt-md-5 pt-4 bg-dark"> 
</div> -->

<div class="d-lg-none manu-middle">    
<ul class="nav justify-content-center">
  <li class="nav-item border-bottom">
    <a class="nav-link "  href="residence.php">explore The property</a>
  </li>
  <li class="nav-item border-bottom border-start">
    <a class="nav-link" href="services.php">explore amenities</a>
  </li>
  <li class="nav-item ">
    <a class="nav-link" href="#floor">explore floor plans</a>
  </li>
  <li class="nav-item border-start">
    <a class="nav-link " href="trump.php">explore about Trump </a>
  </li>
</ul>
</div>
<!-- banner four End -->

<!-- banner five Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
     <div class="col-md-3">
      <p class="para" data-aos="fade-left">
      Take a private luxury car to the entrance of a glass-enclosed lobby and join our gracious community.
      </p>
      <p class="para" data-aos="fade-right">
      The Trump family welcomes you to a life of perfection, exclusivity and refinement.
      </p>
		  <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
     </div>
      <div class="col-md-9">
        <div class="left-part" data-aos="fade-down">
          <img src="img/index/TTK-Lobby-1900x1343.webp" class="img-fluid" />
        </div>
      </div>
    </div>
  </div>
</div>

<!-- floor plans one Start -->
<div class="floor-plans " id="floor">
    <div class="container">
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>TOWER PLANS</h2>
                <!-- <ul>
                    <li>UNIT B - 188 SQ.M/2,022 SQ.FT.</li>
                    <li>UNIT B - 188 SQ.M/2,022 SQ.FT.</li>
                </ul> -->
            </div>
           
            <a href="pdfimg/TOWER-PLANS_page-0001.webp"  class="pdf">               
                <img src="img/floor/TOWER-PLANS.jpg" class="img-fluid" />                
            </a>
         
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>5 BED</h2>
                <ul>
                    <li>UNIT A - 199 SQ.M/2,141 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/5-BED_page-0001.webp" class="pdf">
                <img src="img/floor/5-BED.jpg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>5 BED | TERRACE</h2>
                <ul>
                    <li>UNIT A - 207.8 SQ.M/2,237 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/5-BED-_-TERRACE_page-0001.webp" class="pdf">
                <img src="img/floor/5-BED-_-TERRACE.jpg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>4 BED</h2>
                <ul>
                    <li>UNIT B - 188 SQ.M/2,022 SQ.FT.</li>
                    <li>UNIT C - 170 SQ.M/1,833 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/4-BED-B-and-C_page-0001.webp" class="pdf">
                <img src="img/floor/4-BED.jpg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>4 BED | TERRACE</h2>
                <ul>
                    <li>UNIT C - 177 SQ.M/1,906 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/4-BED-_-TERRACE_pages-to-jpg-0001.webp" class="pdf">
                <img src="img/floor/4-BED-_-TERRACE.jpg" class="img-fluid" />
              
            </a>
        </div>

        <!-- <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>3 BED WITH STUDY</h2>
                <ul>
                    <li>UNIT D - 153 SQ.M/1,644 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdf/3-BED-WITH-STUDY.pdf" target="_blank" class="pdf">
                <img src="img/floor/3-BED-WITH-STUDY.jpeg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>3 BED WITH STUDY | TERRACE</h2>
                <ul>
                    <li>UNIT D - 154 SQ.M/1,656 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdf/3-BED-WITH-STUDY-_-TERRACE.pdf" target="_blank" class="pdf">
                <img src="img/floor/3-BED-WITH-STUDY-_-TERRACE.jpg" class="img-fluid" />
            </a>
        </div> -->
    
    </div>
</div>
<!-- banner one End -->

<div class="call-btn float-end">
        <a class=" btn-secondary what" href="" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule visit</a>
        <a class=" btn-secondary" href="tel:+xxxxxx"><i class="fa fa-phone me-2"></i>9876543210</a>
    </div>
<!-- banner five End -->
<div class="footer-top py-5">

  <a data-aos="fade-up" href="trump.php">EXPLORE THE WORLD OF TRUMP	</a>
</div>

<?php include 'include/footer.php'; ?>