<?php include 'include/header.php'; ?>


<div class="d-lg-none manu-middle">    
<ul class="nav justify-content-center">
  <li class="nav-item border-bottom">
    <a class="nav-link "  href="#">Explore The property</a>
  </li>
  <li class="nav-item border-bottom border-start">
    <a class="nav-link" href="#">Explore AMENITIES</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Explore FLOOR PLANS</a>
  </li>
  <li class="nav-item border-start">
    <a class="nav-link " href="#">Explore about Trump Tower</a>
  </li>
</ul>
</div>

<?php include 'include/footer.php'; ?>