<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="banner  pb-md-4 bg-dark" id="section1">
  <div class="banner-img">
    <img src="img/residence/residence09-1900x894.webp" />
  </div>
  <div class="banner-heading">
    <h5 class="bannn-small" data-aos="fade-down">Trump Tower Kolkata offers a cultivated blend of classically timeless and elegantly modern
      residences. The architecture and design celebrate an individualized sense of ultimate luxury.</h5>
  </div>

  <div class="page__scroll">
    <div class="squares">
      <div class="square"></div>
      <div class="squaretwo"></div>
    </div>

    <p> SCROLL</p>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner one End -->
<?php include 'include/secondrynav.php'; ?>
<!-- banner two Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/residence/living-comp-1900x894.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">CONTEMPORARY SOPHISTICATION</h3>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner two End -->

<!-- banner three Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3">
        <p class="para" data-aos="fade-right">
          Contemporary apartment designs are laid with pure imported marble flooring and elegant, white walls.
        </p>
		  <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
      </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/residence/living-comp-1900x894.webp" class="img-fluid" data-aos="fade-down" />
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner three End -->

<!-- banner four Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/residence/living-classic-1900x894.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">CLASSIC ELEGANCE</h3>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner four End -->

<!-- banner five Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3">
        <p class="para" data-aos="fade-right">
          Classically designed apartments feature flooring patterned with an elegant blend of imported black and white
          marble.
        </p>
		    <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
      </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/residence/living-classic-1900x894.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner five End -->

<!-- banner six Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/residence/Contemp-Bed-Room-1900x894.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">CONTEMPORARY SOPHISTICATION</h3>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner six End -->

<!-- banner seven Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3">
        <p class="para" data-aos="fade-right">
          The minimalist aesthetic of modern master bedrooms is enhanced by imported marble and immaculate white walls.
        </p>
		    <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
      </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/residence/Contemp-Bed-Room-1900x894.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner seven End -->

<!-- banner eight Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/residence/Classic-Bed-Room-1900x894.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">CLASSIC ELEGANCE</h3>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner eight End -->

<!-- banner nine Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3">
        <p class="para" data-aos="fade-right">
          The minimalist aesthetic of modern master bedrooms is enhanced by imported marble and immaculate white walls.
        </p>
		    <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
      </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/residence/Classic-Bed-Room-1900x894.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner nine End -->

<!-- banner ten Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/residence/Cotemp-Bath-Room-1900x894.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">CONTEMPORARY SOPHISTICATION</h3>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner ten End -->

<!-- banner eleven Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3">
        <p class="para" data-aos="fade-right">
          Contemporary bathrooms feature floor-to-ceiling marble that contrasts beautifully with the immaculate white
          countertops.
        </p>
		    <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
      </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/residence/Cotemp-Bath-Room-1900x894.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner eleven End -->


<!-- banner twelve Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/residence/Classic-Bath-Room-1900x894.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">CLASSIC ELEGANCE</h3>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner twelve End -->

<!-- banner therteen Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3">
        <p class="para" data-aos="fade-right">
          In a classical home, the light marble walls of the bathroom extend across the floor to the panoramic glass
          facade.
        </p>
		    <div class="btn golden me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
      </div>
      <div class="col-md-9">
        <div class="left-part">
          <img src="img/residence/Classic-Bath-Room-1900x894.webp" class="img-fluid" data-aos="fade-down"/>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner therteen End -->

<!-- banner fourteen Start -->
<div class="banner py-5" id="section3">
  <div class="container">
    <div class="row g-md-0">
    <div class="col-md-6">
      <div class="col-inner">
      <div class="text-box">
        <h5 data-aos="fade-right">SERENE LAKE</h5>
        <p data-aos="fade-right">
        North-facing rooms offer a relaxed outlook onto the tranquil waters of the lake.
        </p>
      </div>
      <div class="img-box">
        <img src="img/residence/lake.webp" data-aos="fade-down"/>
      </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="col-inner two">
      <div class="img-box">
        <img src="img/residence/city.webp" data-aos="fade-up"/>
      </div>
      <div class="text-box">
  <h5 data-aos="fade-left">GLITTERING CITY</h5>
  <p data-aos="fade-left">South-facing rooms display sweeping views onto Kolkata’s array of urban delights.</p>
      </div>
      </div>
    </div>
    </div>
  </div>
</div>
<div class="spacer">
</div>
<!-- banner fourteen End -->


<!-- banner fifteen Start -->
<div class="banner  " id="section1">
  <div class="banner-img">
    <img src="img/residence/residences-sunset-1900x1263.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h5 class="bannn-small" data-aos="fade-down">Trump Tower Kolkata offers a cultivated blend of classically timeless and elegantly modern
      residences. The architecture and design celebrate an individualized sense of ultimate luxury.</h5>
  </div>


</div>

<!-- banner fifteen End -->

<div class="footer-top py-5">
  <a href="services.php" data-aos="fade-down">EXPLORE SERVICES & AMENITIES</a>
</div>

<?php include 'include/footer.php'; ?>