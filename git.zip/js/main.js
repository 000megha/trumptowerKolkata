


// Function to handle the scroll behavior based on media query
function handleScroll() {
  if (window.matchMedia("(min-width: 768px)").matches) {
    // Your code for screens with a width of 768px or more
    if ($(window).scrollTop() > 300) {
      // Add or remove classes and apply CSS as needed
      $(".sticky-top").addClass("bg-dark shadow-sm").css("top", "0px");
      $(".logo").css("max-width", "100%");
      $(".logo").css("height", "auto");
      $(".nav-link").css("color", "#fff");
      $('.logo').attr("src", 'img/logo-black.webp');
      $(".logo").css("margin-top", "0%");
      $(".logo").css("margin-left", "0%");
      $(".navbar-brand").css("max-width", "80px");
    } else {
      $(".sticky-top").removeClass("bg-dark shadow-sm").css("top", "-150px");
      $(".nav-link").css("color", "#151515");
      $('.logo').attr("src", 'img/logo.webp');
      $(".logo").css("margin-top", "55%");
      $(".logo").css("margin-left", "-23%");
      $(".navbar-brand").css("max-width", "115px");
    }
  } else {
    if ($(window).scrollTop() > 200) {
      // Add or remove classes and apply CSS as needed
      $(".sticky-top").addClass("bg-dark shadow-sm").css("top", "0px");
      $(".logo").css("max-width", "100%");
      $(".logo").css("height", "auto");
      $(".nav-link").css("color", "#151515");
      $('.logo').attr("src", 'img/logo-black.webp');
      $(".logo").css("margin-top", "0%");
      $(".logo").css("margin-left", "0%");
      $(".logo").css("position", "relative");
      $(".logo").css("max-width", "70px");
      // $(".navbar-brand").css("max-width", "80px");
    } else {
      $(".sticky-top").removeClass("bg-dark shadow-sm").css("top", "-150px");
      $(".nav-link").css("color", "#151515");
      $('.logo').attr("src", 'img/logo.webp');
      $(".logo").css("margin-top", "-5%");
      $(".logo").css("margin-left", "-9%");
      $(".logo").css("position", "absolute");
      $(".logo").css("max-width", "70px");
      // $(".navbar-brand").css("max-width", "70px");
    }
  }
}

// Initial call to handleScroll on page load
handleScroll();

// Add a scroll event listener to handle changes when the user scrolls
$(window).scroll(handleScroll);

// Add a resize event listener to handle changes when the window size changes
$(window).resize(handleScroll);



////////////////// magnificPopup
$(document).ready(function () {
  $('.plans').magnificPopup({
      delegate: 'a',
      type: 'image',
      tLoading: 'Loading image #%curr%...',
      mainClass: 'mfp-img-mobile',
       gallery: {
           enabled: true,
           navigateByImgClick: true,
           preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
       },
      image: {
          tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
          titleSrc: function (item) {
              return item.el.attr('title');
          }
      }
  });
});




///////////////// aos
AOS.init({
  offset: 120, // offset (in px) from the original trigger point
  delay: 0, // values from 0 to 3000, with step 50ms
  duration: 1200, // values from 0 to 3000, with step 50ms
  once: false,
});

//validateForm
function validateForm() {
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var mobile = document.getElementById("mobile").value;
  var flattype = document.getElementById("flattype").value;

  // Check if any of the fields are empty
  if (name === "" || email === "" || mobile === "" || flattype === "") {
    alert("Please fill in all required fields.");
    return false;
  }

  // Check if the mobile number starts with 6, 7, 8, or 9 and has exactly 10 digits
  var mobilePattern = /^[6-9]\d{9}$/;
  if (!mobile.match(mobilePattern)) {
    alert("Phone number should be valid and have 10 digits.");
    return false;
  }

  // If all validation checks pass, the form will be submitted
  return true;
}


function validateForm2() {
  var name2 = document.getElementById("name2").value;
  var email2 = document.getElementById("email2").value;
  var mobile2 = document.getElementById("mobile2").value;
  var flattype2 = document.getElementById("flattype2").value;
  // Check if any of the fields are empty
  if (name2 === "" || email2 === "" || mobile2 === "" || flattype2 === "") {
    alert("Please fill in all required fields.");
    return false;
  }

  // Check if the mobile number starts with 6, 7, 8, or 9 and has exactly 10 digits
  var mobilePattern2 = /^[6-9]\d{9}$/;
  if (!mobile2.match(mobilePattern2)) {
    alert("Phone number should be valid and have 10 digits.");
    return false;
  }

  // If all validation checks pass, the form will be submitted
  return true;
}


/////////////////////////////// Function to get parameter value from URL

function getUrlParameter(name) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(name);
}

// Update hidden input fields in all forms
function updateHiddenInputs() {
  const srdValue = getUrlParameter('srd');
  const srdInputs = document.querySelectorAll('form input[type="hidden"][name="srd"]');

  srdInputs.forEach((srdInput) => {
    srdInput.value = srdValue;
  });
}

// Call the updateHiddenInputs function when the page loads
window.addEventListener('load', updateHiddenInputs);

const input = document.querySelector("#mobile");
window.intlTelInput(input, {
  preferredCountries: ["IN", "gb"],
  utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/utils.js",
});
const input2 = document.querySelector("#mobile2");
window.intlTelInput(input2, {
  preferredCountries: ["IN", "gb"],
  utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/utils.js",
});






