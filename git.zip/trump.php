<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="banner  " id="section1">
  <div class="banner-img">
    <img src="img/trump/trump1.webp" />
  </div>
  <div class="banner-heading" >
    <h3 class="bannn-middle" data-aos="fade-down">WELCOME TO THE WORLD OF TRUMP –
      A REALM DEFINED BY TIMELESS ELEGANCE AND
      UNPARALLELED QUALITY</h3>
  </div>

  <div class="page__scroll">
    <div class="squares">
      <div class="square"></div>
      <div class="squaretwo"></div>
    </div>

    <p> SCROLL</p>
  </div>

</div>
<div class="spacer">
</div>
<!-- banner one End -->
<?php include 'include/secondrynav.php'; ?>
<!-- banner two Start -->
<div class="banner py-5" id="section2">
 <div class="container">
 <div class="row justify-content-center">
    <div class="col-md-7">
      <div class="builders">
        <img src="img/trump/don-430x430.webp" class="builder-img" data-aos="fade-right"/>
        <div class="builder-text" data-aos="fade-left">
          <p>I have every reason to expect that Trump Tower Kolkata will be a powerful presence on the Trump
            Organization’s global stage of distinguished properties. It stands as a pinnacle of sophistication among the
            rich collection of developments gracing Kolkata’s skyline. As with every Trump residence, its refined
            architecture is complemented by elegant interiors and unobstructed views over the city’s diverse landscapes.
            What makes Trump Tower Kolkata so unique is the way a resident can choose the views and interior designs
            they consider the vision of perfection. By enabling residents to indulge in personalized luxury and
            world-class amenities, Trump Tower Kolkata will form the most coveted and exclusive community. It will be a
            home created for ultimate sophistication and enjoyment.</p>
            <h5>Donald Trump Jr.</h5>
        </div>
      </div>
    </div>
  </div>
 </div>

</div>
<div class="spacer">
</div>
<!-- banner two End -->

<!-- banner three Start -->
<div class="banner" id="section4">
  <div class="banner-img">
    <img src="img/trump/trump4-1900x895.webp" data-aos="fade-down"/>
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">THE TRUMP LEGACY</h3>
  </div>
</div>

<div class="spacer">
</div>
<!-- banner three End -->

<!-- banner four Start -->
<div class="banner py-5" id="section4">
  <div class="container pb-5">
    <div class="row justify-content-center">
   
      <div class="col-md-4 col-6">
        <div class="column-group">
          <hr>
          <h2 data-aos="fade-right">TRUMP IS SYNONYMOUS WITH CELEBRATED LUXURY</h2>
          <p data-aos="fade-right">The stamp of the Trump brand is a badge of prestige. With a history of developing the world’s finest real estate, there is no match to the Trump standard of service, craftsmanship and aesthetic quality.</p>
          <img  src="img/trump/2-624x1024.webp" class="img-fluid" data-aos="fade-right"/>
        </div>
        <div class="column-group">
          <hr>
          <h2 data-aos="fade-right">A LIFESTYLE OF UNMATCHED PLEASURES</h2>
          <p data-aos="fade-right">Trump opens the gate to a truly enhanced and aspirational lifestyle, fostered within a culture of timeless elegance.</p>
          <img  src="img/trump/1-3-624x1024.webp" class="img-fluid" data-aos="fade-right"/>
        </div>
      </div>
      <div class="col-md-4 col-6">
        <div class="column-group right">
        <img  src="img/trump/4-624x1024.webp" class="img-fluid" data-aos="fade-left"/>
          <hr>
          <h2 data-aos="fade-left">TRUMP IS SYNONYMOUS WITH CELEBRATED LUXURY</h2>
          <p data-aos="fade-left">The stamp of the Trump brand is a badge of prestige. With a history of developing the world’s finest real estate, there is no match to the Trump standard of service, craftsmanship and aesthetic quality.</p>
    
        </div>
        <div class="column-group right">
        <img  src="img/trump/3-624x1024.webp" class="img-fluid" data-aos="fade-left"/>
          <hr>
          <h2 data-aos="fade-left">A LIFESTYLE OF UNMATCHED PLEASURES</h2>
          <p data-aos="fade-left">Trump opens the gate to a truly enhanced and aspirational lifestyle, fostered within a culture of timeless elegance.</p>
        
        </div>
      </div>
    
    </div>
  </div>
 </div>


<!-- banner four End -->
<div class="footer-top py-5">
  <a href="building.php" data-aos="fade-up">EXPLORE THE BUILDING</a>
</div>


<?php include 'include/footer.php'; ?>