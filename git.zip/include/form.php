<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/style.scss" />
</head>

<body>
    <button class="open-button" onclick="openForm()">Reserve your Trump Experience</button>

    <div class="form-popup" id="myForm">
    
        <form action="./mail.php" method="post" class="form-container">
        <h4 class="text-dark mb-3">
                        CONTACT FORM
                        </h4>
        <button type="button" class="cancel" onclick="closeForm()">⨉</button>
            <div class="form-group">
                <label for="name">* Name:</label>
                <input type="text" id="name" name="name" placeholder="Name" required>
            </div>
            <div class="form-group">
                <label for="email">* Email:</label>
                <input type="text" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label for="mobile">* Phone Number:</label>
                <input type="text" pattern="[6-9]\d{9}" id="mobile" name="mobile" placeholder="Phone Number" required>
            </div>



            <input type="submit" name="button" value="Submit" class="btn custombtn">

        </form>
    </div>

    <script>
          function openForm() {
        var form = document.getElementById("myForm");
        form.style.transform = "translateX(0)";
    }

    function closeForm() {
        var form = document.getElementById("myForm");
        form.style.transform = "translateX(-100%)";
    }
    </script>
</body>

</html>