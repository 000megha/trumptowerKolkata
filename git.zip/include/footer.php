<!-- Footer Start -->
<?php include 'modalform.php'; ?>
<?php include 'broshure.php'; ?>


<div class="copyright">
  <P>PROJECT BY </p>
  <img src="img/icon/1.png" />
  <img src="img/icon/2.png" />
  <img src="img/icon/3.png" />
</div>

<div class="outro">

  <div class="container ">
    <div class="row justify-content-center">
      <div class="col-md-10">
        <div class="shell">
          <p>Trump Tower Kolkata is not owned, developed or sold by The Trump Organization or any of their current or
            former principals or affiliates.&nbsp; Concast Infrastructure Pvt. Ltd., the owner and developer of the
            property, uses the “Trump” name and mark under license, which license may be terminated or revoked according
            to its terms. The Trump Organization and its affiliates, and any of their respective current or former
            principals or employees, does not own, control or operate this website or any of Concast Infrastructure Pvt.
            Ltd.’s other websites, and therefore are not responsible for the collection, storage, use and sharing of any
            information in connection therewith. The HIRA no is – HIRA/P/KOL/2019/000341.</p>
        </div><!-- /.shell -->
      </div>
    </div>
  </div>
  
</div>

<div class="call-btn float-end">
        <a class=" btn-secondary what" href="" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule visit</a>
        <a class=" btn-secondary" href="tel:+919836574000"><i class="fa fa-phone me-2"></i>+919836574000</a>
    </div>
<!-- Footer End -->

<!-- jqury cdn -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/jquery.magnific-popup.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
  integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
  integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"></script>
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>


<script src="js/main.js"></script>

</body>

</html>