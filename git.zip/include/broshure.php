<!-- Modal -->
<div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
     
      <div class="form-outer">
        
                    <div class="form-container" data-aos="fade-right" >
                    <button type="button" class="btn-close " data-bs-dismiss="modal" aria-label="Close"></button>
                        <h4 class="text-dark mb-4">
                        DOWNLOAD BROCHURE
                        </h4>

                        <form action="mail.php" method="post" autocomplete="off">
                            <div class="form-group">
                                <label for="name">* Name:</label>
                                <input type="text" id="name" name="name" placeholder="Name" required>
                            </div>
                            <div class="form-group">
                                <label for="email">* Email:</label>
                                <input type="text" id="email" name="email" placeholder="Email" required>
                            </div>
                            <div class="form-group">
                                <label for="mobile">* Phone Number:</label>
                                <input type="text" maxlength="10" id="mobile" name="mobile" placeholder="Phone Number" required>
                            </div>
								 <div class="form-group">
                                <label for="mobile">* Choose Your Preferred Flat Type:</label>
                                    <select class=" form-control form-select" tabindex="5"
                                            aria-label="Default select example" id="flattype" name="flattype" required>
                                            <option value="" disabled="disabled" selected>Select Flat type*</option>
                                            <option value="4BHK">4BHK 5.5CR</option>
                                            <option value="5BHK">5BHK 7CR</option>
                                        </select>
                            </div>
                            <div class="form-group">
                                <label for="message"> Message:</label>
                                <textarea id="message" name="message" class="form-control"
                                    placeholder="Enter Your Message" rows="2" cols="50"></textarea>
                            </div>
							      <input type="hidden" id="srd" name="srd">
                            <input type="submit" onclick="return validateForm()" name="button" value="Submit" class="btn custombtn">
                        </form>
                    </div>
                </div>
    </div>
  </div>
</div>
