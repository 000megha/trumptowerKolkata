<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php 
 $path = $_SERVER['REQUEST_URI'];
 $path = explode('/', $path);
  $path = end($path);
?>

</head>

<body>



  <div id="secondry-navbar" class="d-lg-none">
    <a class="nav-item nav-link " <?php if($path=='services.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="services.php">AMENITIES </a>
    <a class="nav-item nav-link " <?php if($path=='index.php#floor' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="index.php#floor">FLOOR PLANS </a>
    <a class="nav-item nav-link " <?php if($path=='story.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="story.php">STORY </a>  
    <a class="nav-item nav-link " <?php if($path=='residence.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="residence.php">RESIDENCES </a>
    <a class="nav-item nav-link " <?php if($path=='building.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="building.php">BUILDING </a>
    <a class="nav-item nav-link " <?php if($path=='trump.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="trump.php">TRUMP </a>
	    <a class="nav-item nav-link " <?php if($path=='developers.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="developers.php">DEVELOPERS </a>
    <a class="nav-item nav-link " <?php if($path=='contact.php' ) {echo "class='nav-item nav-link active'" ;} ?>
      href="contact.php">CONTACT</a>
  </div>



  <script>
    window.onscroll = function () { myFunction() };

    var navbar = document.getElementById("secondry-navbar");
    var sticky = navbar.offsetTop;

    function myFunction() {
      if (window.pageYOffset >= sticky) {
        navbar.classList.add("secondry-sticky")
      } else {
        navbar.classList.remove("secondry-sticky");
      }
    }
  </script>

</body>

</html>