<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <?php 
 $path = $_SERVER['REQUEST_URI'];
 $path = explode('/', $path);
  $path = end($path);
?>

  <title>Trump &#8211; Trump Tower Kolkata &#8211; World&#039;s Most Recognizable Address</title>
  <link rel="icon" type="image/x-icon" href="img/favicon.png" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous" />
  <!-- font awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <!-- slick -->


  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/style.scss" />
  <!-- Include GSAP and ScrollTrigger via CDN -->

  <!-- slick  -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- intlTelInput -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css">
  <!-- magnifying popup -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/magnific-popup@1.1.0/dist/magnific-popup.css">
	
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NBXP4D3S');</script>
<!-- End Google Tag Manager -->
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NBXP4D3S"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
	
	
  <!-- Navbar Start -->
  <div class="sticky-top container-fluid ">
    <div class="container-fluid">
      <nav class="navbar navbar-expand-lg navbar-dark p-0">
        <a href="index.php" class="navbar-brand ">
          <img src="img/logo.webp" class="img-fluid logo " />
        </a>
        <button type="button" class="navbar-toggler ms-auto me-0" type="button" data-bs-toggle="offcanvas"
          data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <div class="navbar-nav ms-auto">
            <a class="nav-item nav-link " <?php if($path=='trump.php' ) {echo "class='nav-item nav-link active'" ;} ?>
              href="trump.php">TRUMP </a>
            <a class="nav-item nav-link " <?php if($path=='building.php' ) {echo "class='nav-item nav-link active'" ;}
              ?> href="building.php">BUILDING </a>
            <a class="nav-item nav-link " <?php if($path=='story.php' ) {echo "class='nav-item nav-link active'" ;} ?>
              href="story.php">STORY </a>
            <a class="nav-item nav-link " <?php if($path=='residence.php' ) {echo "class='nav-item nav-link active'" ;}
              ?> href="residence.php">RESIDENCES </a>
            <a class="nav-item nav-link " <?php if($path=='services.php' ) {echo "class='nav-item nav-link active'" ;}
              ?> href="services.php">SERVICES & AMENITIES </a>
            <a class="nav-item nav-link " <?php if($path=='index.php#floor' ) {echo "class='nav-item nav-link active'"
              ;} ?> href="index.php#floor">FLOOR PLANS </a>
            <a class="nav-item nav-link " <?php if($path=='developers.php' ) {echo "class='nav-item nav-link active'" ;}
              ?> href="developers.php">DEVELOPERS </a>
            <a class="nav-item nav-link " <?php if($path=='contact.php' ) {echo "class='nav-item nav-link active'" ;} ?>
              href="contact.php">CONTACT</a>
          </div>
          <!-- <a type="button" class="btn d-none d-lg-block" href="form.php">
            Get Free Quote
          </a> -->
        </div>

        <div class="offcanvas offcanvas-start d-lg-none" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1"
          id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
          <div class="offcanvas-header">
            <img src="img/logo-black.webp" class="img-fluid  offcanvas-title" id="offcanvasScrollingLabel" width="70" />

            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
            <div class="offcanvas-nav ms-auto">
              <a href="index.php" class="nav-item nav-link active mb-3 ms-3">HOME</a>
              <a href="trump.php" class="nav-item nav-link mb-3 ms-3">TRUMP </a>
              <a href="building.php" class="nav-item nav-link mb-3 ms-3">BUILDING </a>
              <a href="story.php" class="nav-item nav-link mb-3 ms-3">STORY </a>
              <a href="residence.php" class="nav-item nav-link mb-3 ms-3">RESIDENCES </a>
              <a href="services.php" class="nav-item nav-link mb-3 ms-3">SERVICES & AMENITIES </a>
              <a href="index.php#floor" class="nav-item nav-link mb-3 ms-3">FLOOR PLANS </a>
              <a href="developers.php" class="nav-item nav-link mb-3 ms-3">DEVELOPERS </a>
              <a href="contact.php" class="nav-item nav-link ms-3">CONTACT</a>
              <!-- <a type="button" class="btn" href="form.php">
                Get Free Quote
              </a> -->
            </div>
          </div>
        </div>
      </nav>
    </div>
  </div>
  <!-- Navbar End -->