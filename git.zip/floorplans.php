<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="floor-plans " id="section1">
    <div class="container">
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>TOWER PLANS</h2>
                <!-- <ul>
                    <li>UNIT B - 188 SQ.M/2,022 SQ.FT.</li>
                    <li>UNIT B - 188 SQ.M/2,022 SQ.FT.</li>
                </ul> -->
            </div>
           
            <a href="pdfimg/TOWER-PLANS_page-0001.webp"  class="pdf">               
                <img src="img/floor/TOWER-PLANS.jpg" class="img-fluid" />                
            </a>
         
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>5 BED</h2>
                <ul>
                    <li>UNIT A - 199 SQ.M/2,141 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/5-BED_page-0001.webp" class="pdf">
                <img src="img/floor/5-BED.jpg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>5 BED | TERRACE</h2>
                <ul>
                    <li>UNIT A - 207.8 SQ.M/2,237 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/5-BED-_-TERRACE_page-0001.webp" class="pdf">
                <img src="img/floor/5-BED-_-TERRACE.jpg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>4 BED</h2>
                <ul>
                    <li>UNIT B - 188 SQ.M/2,022 SQ.FT.</li>
                    <li>UNIT C - 170 SQ.M/1,833 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/4-BED-B-and-C_page-0001.webp" class="pdf">
                <img src="img/floor/4-BED.jpg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>4 BED | TERRACE</h2>
                <ul>
                    <li>UNIT C - 177 SQ.M/1,906 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdfimg/4-BED-_-TERRACE_pages-to-jpg-0001.webp" class="pdf">
                <img src="img/floor/4-BED-_-TERRACE.jpg" class="img-fluid" />
              
            </a>
        </div>

        <!-- <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>3 BED WITH STUDY</h2>
                <ul>
                    <li>UNIT D - 153 SQ.M/1,644 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdf/3-BED-WITH-STUDY.pdf" target="_blank" class="pdf">
                <img src="img/floor/3-BED-WITH-STUDY.jpeg" class="img-fluid" />
            </a>
        </div>
        <div class="plans" data-aos="fade-down">
            <div class="txt">
                <h2>3 BED WITH STUDY | TERRACE</h2>
                <ul>
                    <li>UNIT D - 154 SQ.M/1,656 SQ.FT.</li>
                </ul>
            </div>
            <a href="pdf/3-BED-WITH-STUDY-_-TERRACE.pdf" target="_blank" class="pdf">
                <img src="img/floor/3-BED-WITH-STUDY-_-TERRACE.jpg" class="img-fluid" />
            </a>
        </div> -->
    
    </div>
</div>


<!-- banner one End -->

<?php include 'include/footer.php'; ?>