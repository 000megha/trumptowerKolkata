<?php include 'include/header.php'; ?>


<!-- banner one Start -->
<div class="banner  " id="section1">
  <div class="banner-img">
    <img src="img/developers/intro1-1900x466.webp" />
  </div>

</div>
<div class="spacer">
</div>
<!-- banner one End -->

<?php include 'include/secondrynav.php'; ?>

<!-- banner two Start -->
<div class="banner  py-5" id="section1">
  <div class="container">
    <div class="row g-md-5">
      <div class="col-md-4">
        <div class="devloper" data-aos="fade-down">
          <div class="dev-img">
            <img src="img/icon/section-image2.png" />
          </div>
          <p>Unimark Group is a one of the leading real estate companies in Kolkata. The group strives to build amazing
            and sustainable residences, commercial hubs and malls so that it can contribute in building a better city
            and
            be known as the best real estate developers in Kolkata. The minds at Unimark Group envision impeccable
            possibilities, perceiving properties as a blank canvas to paint unbounded imagination.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="devloper" data-aos="fade-down">
          <div class="dev-img">
            <img src="img/icon/section-image1.png" />
          </div>
          <p>RDB Group, under the able leadership of Sri Sunder Lal Dugar, has interests in Real Estate &
            Infrastructure,
            Bulk Packing Solutions, Transmission Lines, Automobiles Marketing, Education and Transport & Logistics. RDB
            Group has a pan-India presence with all the necessary infrastructure, manpower and finance, fostering an
            environment of professionalism in its workforce of over 5000 employees.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="devloper" data-aos="fade-down">
          <div class="dev-img">
            <img src="img/icon/section-image3.png" />
          </div>
          <p>Tribeca is a new age real estate development firm, founded on the desire to inspire and delight. Truly
            great
            developments can achieve this through the fusion of thoughtful design, detailed craftsmanship and ideal
            partnerships. Tribeca works by these principles, building architecture based on art and relationships based
            on
            transparency. Tribeca believes bringing the best to India takes tying up with the best in the world.</p>
        </div>
      </div>
    </div>
  </div>

</div>

<div class="spacer">
</div>
<!-- banner two End -->


<!-- banner three Start -->
<div class="services dev" id="section4" style="background-color:#322f31;">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-md-7 g-0">
        <div class="left-bg">
          <img src="img/developers/developers2.webp" class="img-fluid" data-aos="fade-left"/>
        </div>
      </div>
      <div class="col-md-5 g-0">
        <div class="devloper-text" data-aos="fade-right">
          <h2>TRUMP + TRIBECA</h2>
          <p>Tribeca believes bringing the best to India takes tying up with the best in the world. That includes the
            Trump Brand – one of the most recognized real estate empires across the globe.</p>
          <p>Tribeca has worked with the Trump Brand for the last 7 years and has been instrumental in creating the
            largest portfolio of Trump properties outside of North America. Collaborating closely with the Trump team in
            New York and local Indian developers, Tribeca has identified the most ideal sites for Trump-branded projects
            in India. They are involved in every aspect of the development – from construction and design to sales and
            marketing – to ensure its conceptualization and execution is up to par with the high global standards of
            Trump.</p>
          <p>Together, Trump and Tribeca bridge the best of global practices and conveniences with a sensitivity to the
            local market nuances.</p>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- banner three End -->




<?php include 'include/footer.php'; ?>