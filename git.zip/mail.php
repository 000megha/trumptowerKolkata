<?php
	if(isset($_POST['button'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
		$message = $_POST['message'];
		$flattype = $_POST['flattype'];
		    if (containsLinks($message)) {
        // Redirect to the thank you page without submitting the form
       header("Location: https://trumptowerkolkata.com/thankyou.php");
        exit();
    }
		if (isset($_POST['srd']) && strlen($_POST['srd']) > 1) {
    
			$srd = $_POST['srd'];
		} else {
		   
			$srd = '654b2ef058f1e79cc5155166';
		}
		$emailData = [
			'sender' => [
				'name' => 'TRUMP TOWER',
				'email' => 'ruhialx@gmail.com'
			],
			'to' => [
				[
					'email' => 'megha@markobrando.com',
					'name' => 'Marko'
				]
			],
			'subject' => 'Trumptower Form Details received',
			'htmlContent' => "<html><head></head><body><table border='1'><tbody><tr><th> Name</th><td>" .$name. "<td></tr><tr><th>Email</th><td>" .$email. "<td></tr><tr><th>Mobile</th><td>" .$mobile. "<td></tr><tr><th>Flattype</th><td>" .$flattype. "<td></tr><tr><th>Message</th><td>" .$message. "<td></tr><tr><th>srd (if any)</th><td>" .htmlspecialchars($srd) . "</td></tr></tbody></table></body></html>"
		];

		// Convert email data to JSON format
		$jsonData = json_encode($emailData);

		// Set the Brevo API endpoint URL
		$apiUrl = 'https://api.brevo.com/v3/smtp/email';

		// Initialize cURL session
		$curl = curl_init();

		// Set cURL options
		curl_setopt_array($curl, [
			CURLOPT_URL => $apiUrl,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $jsonData,
			CURLOPT_HTTPHEADER => [
				'Accept: application/json',
				'Api-Key: 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',
				'Content-Type: application/json'
			],
		]);

		// Execute the cURL request
		$response = curl_exec($curl);
		curl_close($curl);
		// Check if cURL request was successful
		if ($response === false) {
			echo 'Error: ' . curl_error($curl);
			exit;
		} 
		

		$url = 'https://app.sell.do/api/leads/create?api_key=ed42ad7ebd3b2c83c25646ba7eabdb3c&sell_do[form][lead][name]='.urlencode($name).'&sell_do[form][lead][email]='.urlencode($email).'&sell_do[form][lead][phone]='.urlencode($mobile).'&sell_do[campaign][srd]='.urlencode($srd).'&sell_do[form][lead][note]='.urlencode($flattype);

		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET'
		));
		$response2 = curl_exec($curl);
		curl_close($curl);
		if($response2){
			header("Location: thankyou.php");
			exit;
			
			
		}
		else{
			echo 'Error: ' . curl_error($curl);
		}
		//1808

	}

function containsLinks($text)
{
    // Define regular expression pattern to match URLs
    $pattern = "/(http|https|www)[^\s]+/";
    // Use preg_match to check if the pattern is found in the text
    return preg_match($pattern, $text);
}

?>