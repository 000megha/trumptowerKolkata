<?php include 'include/header.php'; ?>

<?php include 'include/modalform.php'; ?>

<!-- banner one Start -->
<div class="banner bg-light pb-md-5  " id="section1">
  <div class="banner-img">
    <img src="img/services/service-r-1900x1344.webp" />
  </div>
  <div class="banner-heading">
    <h3 class="bannn-middle" data-aos="fade-down">WHILE IMBIBING THE MOST SOPHISTICATED ELEMENTS OF THE CITY’S RICH
      CULTURE, TRUMP TOWER KOLKATA INTRODUCES EXCLUSIVE PLEASURES, AMENITIES AND SERVICES.</h3>
  </div>

  <div class="page__scroll">
    <div class="squares">
      <div class="square"></div>
      <div class="squaretwo"></div>
    </div>
    <p> SCROLL</p>
  </div>
</div>

<!-- banner one End -->

<?php include 'include/secondrynav.php'; ?>

<!-- banner two Start -->
<div class="services" id="section4">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-md-7 g-0">
        <div class="left-bg">
          <img src="img/services/Fitness-Centre.webp" class="img-fluid" data-aos="fade-down" />
        </div>
      </div>
      <div class="col-md-5">
        <div class="service-text" data-aos="fade-up">
          <h2>UNPRECEDENTED AMENITY SPACES</h2>
          <ul>
            <li>
              <p>Fitness Center with Steam, Sauna and Locker Rooms</p>
            </li>
            <li>
              <p>Yoga/Dance Studios</p>
            </li>
            <li>
              <p>Kids Play Area</p>
            </li>
          </ul>

          <div class="btn me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>

        </div>
      </div>
    </div>
  </div>
</div>

<div class="spacer pt-md-5 pt-0 bg-light">
</div>
<!-- banner two End -->


<!-- banner three Start -->
<div class="services" id="section4">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-md-7 g-0">
        <div class="left-bg">
          <img src="img/services/TTK-Cigar-Lounge-HR1.webp" class="img-fluid" data-aos="fade-down" />
        </div>
      </div>
      <div class="col-md-5">
        <div class="service-text" data-aos="fade-up">
          <h2>UNPRECEDENTED AMENITY SPACES</h2>
          <ul>
            <li>
              <p>Exclusive Cigar & Wine Lounge</p>
            </li>
            <li>
              <p>Private Theatre</p>
            </li>
            <li>
              <p>Entertainment Terrace</p>
            </li>
            <li>
              <p>Indoor Games Room with Tables for Pool, Foosball, Table Tennis & Squash Court</p>
            </li>
          </ul>
          <div class="btn me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="spacer pt-md-5 pt-0 bg-light">
</div>
<!-- banner three End -->


<!-- banner four Start -->
<div class="services" id="section4">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-md-7 g-0">
        <div class="left-bg">
          <img src="img/services/Restaurant_Amenities.webp" class="img-fluid" data-aos="fade-down" />
        </div>
      </div>
      <div class="col-md-5">
        <div class="service-text" data-aos="fade-up">
          <h2>UNPRECEDENTED AMENITY SPACES</h2>
          <ul>
            <li>
              <p>Rooftop Private Dining Space with Banquet Hall</p>
            </li>
          </ul>
          <a class="btn me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</a>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="spacer pt-md-5 pt-0 bg-light">
</div>
<!-- banner four End -->


<!-- banner five Start -->
<div class="services" id="section4">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-md-7 g-0">
        <div class="left-bg" data-aos="fade-down">
          <img src="img/services/POOL_Amenities.webp" class="img-fluid" />
        </div>
      </div>
      <div class="col-md-5">
        <div class="service-text" data-aos="fade-up">
          <h2>UNPRECEDENTED AMENITY SPACES</h2>
          <ul>
            <li>
              <p>Rooftop Skye Club with Heated Pool</p>
            </li>
            <li>
              <p>Sun Terrace</p>
            </li>
          </ul>
          <div class="btn me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="spacer pt-md-5 pt-0 bg-light">
</div>
<!-- banner five End -->


<!-- banner five Start -->
<div class="services" id="section4">
  <div class="container-fluid">
    <div class="row ">
      <div class="col-md-7 g-0">
        <div class="left-bg" data-aos="fade-down">
          <img src="img/services/services4.webp" class="img-fluid" />
        </div>
      </div>
      <div class="col-md-5">
        <div class="service-text" data-aos="fade-up">
          <h2>PRIVATE SERVICES</h2>
          <ul>
            <li>
              <p>24/7 Doorman & Lifestyle Concierge</p>
            </li>
            <li>
              <p>Dry Cleaning & Laundry Service</p>
            </li>
            <li>
              <p>Housekeeping Service</p>
            </li>
            <li>
              <p>Valet Service</p>
            </li>
            <li>
              <p>White Gloved Services such as On-call Chef & On-call Butler</p>
            </li>
            <li>
              <p>Resident Fitness Trainers</p>
            </li>
            <li>
              <p>On-call Nurse</p>
            </li>
          </ul>
          <div class="btn me-md-4" data-bs-toggle="modal" data-bs-target="#exampleModal">schedule a site visit</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- banner five End -->
<div class="footer-top py-5">
  <a href="index.php#floor" data-aos="fade-down">EXPLORE FLOOR PLANS </a>
</div>

<?php include 'include/footer.php'; ?>